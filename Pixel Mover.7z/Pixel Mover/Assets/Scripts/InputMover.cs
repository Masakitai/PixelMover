﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InputMover : MonoBehaviour
{
    // create can move cant move toggler
    bool canMove = true;
    public GameObject thisObject;
    // Use this for initialization
    void Start()
    {
        
    }

	// Update is called once per frame
	void Update ()
    {
        // if p is pressed
        if (Input.GetKey(KeyCode.P))
        {
            //toggle if can move
            if (canMove == true)
            {
                canMove = false;
            }
            else if (canMove == false)
            {
                canMove = true;
            }
        }

        // if can move is on
        if (canMove == true)
        {
            //if left shift is pressed
            if (Input.GetKey(KeyCode.LeftShift))
            {
                if (Input.GetKeyDown(KeyCode.LeftArrow)|| Input.GetKeyDown(KeyCode.RightArrow)|| Input.GetKeyDown(KeyCode.UpArrow)|| Input.GetKeyDown(KeyCode.DownArrow))
                transform.Translate(Input.GetAxis("Horizontal") * 1, Input.GetAxis("Vertical") * 1, 0f);
            }
            //if space is pressed
            else if (Input.GetKey(KeyCode.Space))
            {
                //center snap
                transform.localPosition = new Vector3(0, 0, 0);

            }
            //movement
            else transform.Translate(Input.GetAxis("Horizontal") * Time.deltaTime, Input.GetAxis("Vertical") * Time.deltaTime, 0f);
        }
        //If Q is pressed
        if (Input.GetKey(KeyCode.Q))
        {
            thisObject.SetActive(false);
        }

        //if esc is pressed
        if (Input.GetKey(KeyCode.Escape))
        {
            Application.Quit();
        }
         
        
    }
}
